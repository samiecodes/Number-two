/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.circlecalculator1;

/**
 *
 * @author HP
 */
import java.util.Scanner;

class Circle {
    private double radius;
    private static final double PI = 22.0 / 7.0;

    public Circle(double radius) {
        this.radius = radius;
    }

    public double calculateArea() {
        return PI * radius * radius;
    }

    public double calculateCircumference() {
        return 2 * PI * radius;
    }
}

public class CircleCalculator1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the radius of the circle: ");
        double radius = scanner.nextDouble();

        Circle circle = new Circle(radius);

        double area = circle.calculateArea();
        double circumference = circle.calculateCircumference();

        System.out.printf("Area of the circle: %.2f%n", area);
        System.out.printf("Circumference of the circle: %.2f%n", circumference);
    }
}
